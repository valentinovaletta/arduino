/*
  Morse_encoder.h - Library for encode messages from com port to LED signals.
  Created by Valentin, 20.10.2021.
  Released into the public domain.
*/
#ifndef Morse_h
#define Morse_h

#include "Arduino.h"

class Morse {
  public:
    Morse(int pin, int default_signal_length);
    void dot();
    void dash();
    void codeMessage(String message);
  private:
    int _pin;
    int _default_signal_length;
    void delay_sign(int n);
    void showmessage(String message);
};

#endif
