/*
  Morse_encoder.cpp - Library for encode messages from com port to LED signals.
  Created by Valentin, 20.10.2021.
  Released into the public domain.
*/

#include "Arduino.h"
#include "morse_encoder.h"
#include "alphabet.h"

Morse::Morse(int pin, int default_signal_length){
  pinMode(pin, OUTPUT);
  _pin = pin;
  _default_signal_length = default_signal_length;
};
void Morse::delay_sign(int n){
  delay(_default_signal_length * n);
}
void Morse::dot(){
      digitalWrite(_pin, HIGH);
      delay(_default_signal_length);
      digitalWrite(_pin, LOW);
      delay_sign(1);
}
void Morse::dash(){
      digitalWrite(_pin, HIGH);
      delay(_default_signal_length*3);
      digitalWrite(_pin, LOW);
      delay_sign(1);
}
void Morse::codeMessage(String message){
  int len, ch_code;
  String ch;
  len = message.length();
    for (int i = 0; i < len; i++){
      ch = message.charAt(i);
          
            for (int j=0; j<27; j++) {  // j = length of alphabet array
               if (ch == abc[j]) {
                 ch_code = j;
                 break;
               }
            }          
            //Serial.println( codes[ch_code] );
            showmessage( codes[ch_code] );
    }  
}
void Morse::showmessage(String message){
  String ch;
    for (int i = 0; i <  message.length(); i++){
      ch = message.charAt(i);
      if (ch == "*") {dot();}
      if (ch == "-") {dash();}
      if (ch == "~") {delay_sign(7);}
    }
    delay_sign(3);
}
